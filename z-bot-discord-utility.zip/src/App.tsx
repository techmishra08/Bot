import { useState, useEffect } from 'react';
import { Shield, Zap, Users, MessageSquare, Trash2, Ban } from 'lucide-react';
import { motion } from 'motion/react';

export default function App() {
  const [status, setStatus] = useState('Checking...');

  useEffect(() => {
    fetch('/api/health')
      .then(res => res.json())
      .then(data => setStatus(data.status === 'ok' ? 'Online' : 'Error'))
      .catch(() => setStatus('Offline'));
  }, []);

  const features = [
    { icon: <MessageSquare className="w-5 h-5" />, title: 'Zspam', desc: 'High-speed message broadcasting with Embed feedback' },
    { icon: <Zap className="w-5 h-5" />, title: 'Zmchannel', desc: 'Instant mass channel creation' },
    { icon: <Shield className="w-5 h-5" />, title: 'Zmrole', desc: 'Instant mass role creation' },
    { icon: <Ban className="w-5 h-5" />, title: 'Z massbann', desc: 'Secure server cleanup with protocol logs' },
    { icon: <Trash2 className="w-5 h-5" />, title: 'Zdz', desc: 'Complete server reset' },
    { icon: <Users className="w-5 h-5" />, title: 'Zstats', desc: 'Real-time performance metrics' },
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-sans selection:bg-emerald-500/30">
      {/* Header */}
      <nav className="border-b border-white/5 bg-black/20 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center shadow-[0_0_20px_rgba(16,185,129,0.3)]">
              <span className="font-bold text-black text-xl">Z</span>
            </div>
            <span className="font-semibold tracking-tight text-lg">Z-Bot Control</span>
          </div>
          <div className="flex items-center gap-4">
            <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium border ${
              status === 'Online' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border-red-500/20 text-red-400'
            }`}>
              <div className={`w-1.5 h-1.5 rounded-full ${status === 'Online' ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'}`} />
              System {status}
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-6 py-12">
        {/* Hero */}
        <div className="mb-16">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm font-bold mb-6"
          >
            <Zap className="w-4 h-4 fill-emerald-400" />
            LOW LATENCY OPTIMIZED (10-20MS TARGET)
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-6xl font-bold tracking-tighter mb-4 bg-gradient-to-b from-white to-white/50 bg-clip-text text-transparent"
          >
            Single-Line Execution.<br />Zero Prompts.
          </motion.h1>
          <p className="text-zinc-400 text-xl max-w-2xl leading-relaxed">
            A high-performance Discord utility engineered for speed. All commands execute instantly from a single message. No collectors, no delays.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="p-6 rounded-2xl bg-white/[0.02] border border-white/5 hover:bg-white/[0.04] hover:border-white/10 transition-all group"
            >
              <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                {f.icon}
              </div>
              <h3 className="text-lg font-semibold mb-1">{f.title}</h3>
              <p className="text-zinc-500 text-sm">{f.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* Command Guide */}
        <div className="mt-16 p-8 rounded-3xl bg-gradient-to-br from-emerald-500/10 to-transparent border border-emerald-500/10">
          <h2 className="text-2xl font-bold mb-6">Quick Reference</h2>
          <div className="space-y-4 font-mono text-sm">
            <div className="flex items-center gap-4 p-3 rounded-lg bg-black/40 border border-white/5">
              <span className="text-emerald-400 w-48 shrink-0">Zspam 50 all raid</span>
              <span className="text-zinc-500">Sends 50 messages to all channels</span>
            </div>
            <div className="flex items-center gap-4 p-3 rounded-lg bg-black/40 border border-white/5">
              <span className="text-emerald-400 w-48 shrink-0">Zmchannel 10 raid</span>
              <span className="text-zinc-500">Creates 10 channels named "raid"</span>
            </div>
            <div className="flex items-center gap-4 p-3 rounded-lg bg-black/40 border border-white/5">
              <span className="text-emerald-400 w-48 shrink-0">Z massbann</span>
              <span className="text-zinc-500">Bans all non-whitelisted members</span>
            </div>
            <div className="flex items-center gap-4 p-3 rounded-lg bg-black/40 border border-white/5">
              <span className="text-emerald-400 w-48 shrink-0">Zping</span>
              <span className="text-zinc-500">Check real-time WebSocket and API latency</span>
            </div>
            <div className="flex items-center gap-4 p-3 rounded-lg bg-black/40 border border-white/5">
              <span className="text-emerald-400 w-48 shrink-0">Zstats</span>
              <span className="text-zinc-500">Shows real-time system performance</span>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
